


from .manager import auth_manager 

classes =[]

__all__ =['classes','auth_manager']


def register ():
    """Register auth module."""

    pass 


def unregister ():
    """Unregister auth module."""

    pass 